import { Routes } from '@angular/router';
import { productscomponent } from './products/products.component'; //1


export const routes: Routes = [
//2
{
    path: 'products',
    component: productscomponent
}

];
